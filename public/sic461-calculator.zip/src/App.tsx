import React, { useState, useRef, useMemo } from 'react';
import { CalculatorInputs, PresetProfile } from './types/calculator';
import { calculateSiC461, generateBomList } from './utils/sic461Math';
import { PRESET_PROFILES } from './utils/presets';
import { Header } from './components/Header';
import { InputPanel } from './components/InputPanel';
import { SchematicView } from './components/SchematicView';
import { BomTable } from './components/BomTable';
import { WaveformChart } from './components/WaveformChart';
import { PythonExportModal } from './components/PythonExportModal';
import { CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';

export default function App() {
  const [inputs, setInputs] = useState<CalculatorInputs>(
    PRESET_PROFILES[0].inputs
  );
  const [selectedPresetId, setSelectedPresetId] = useState<string>(
    PRESET_PROFILES[0].id
  );
  const [activeTab, setActiveTab] = useState<'schematic' | 'bom' | 'analysis'>(
    'schematic'
  );
  const [isPythonModalOpen, setIsPythonModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Instant real-time calculation
  const results = useMemo(() => calculateSiC461(inputs), [inputs]);
  const bomItems = useMemo(
    () => generateBomList(inputs, results),
    [inputs, results]
  );

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleInputChange = <K extends keyof CalculatorInputs>(
    field: K,
    value: CalculatorInputs[K]
  ) => {
    setInputs((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSelectPreset = (preset: PresetProfile) => {
    setSelectedPresetId(preset.id);
    setInputs(preset.inputs);
    showToast(`Применен пресет: ${preset.name}`);
  };

  const handleResetDefaults = () => {
    setInputs(PRESET_PROFILES[0].inputs);
    setSelectedPresetId(PRESET_PROFILES[0].id);
    showToast('Сброшено к заводскому профилю 24В → 5В @ 10А');
  };

  // Export current design to JSON file
  const handleExportJson = () => {
    const exportData = {
      device: 'Vishay SiC461 Synchronous Buck Regulator',
      version: '1.1',
      timestamp: new Date().toISOString(),
      inputModes: {
        voutInputMode: inputs.voutInputMode, // 'voltage' | 'resistors'
        softStartInputMode: inputs.softStartInputMode, // 'time' | 'capacitor'
        uvloInputMode: inputs.uvloInputMode, // 'voltage' | 'resistors'
      },
      inputComponents: {
        rfb1Kohm: inputs.rfb1Kohm,
        rfb2Kohm: inputs.rfb2Kohm,
        cssNf: inputs.cssNf,
        ren1Kohm: inputs.ren1Kohm,
        ren2Kohm: inputs.ren2Kohm,
      },
      inputs,
      calculatedSummary: {
        dutyNominal: results.dutyNom,
        inductorNominalUh: results.lNominal.nominal,
        coutTotalUf: results.coutQty * results.coutSingleUf,
        cinTotalUf: results.cinQty * results.cinSingleUf,
        rfbTopKohm: results.rfbTop.nominal,
        rfbBottomKohm: results.rfbBottom.nominal,
        actualVout: results.voutActual,
        actualRippleMv: results.actualRippleMv,
        actualTssMs: results.actualTssMs,
        actualVinStart: results.actualVinStart,
        actualVinStop: results.actualVinStop,
        estimatedEfficiency: results.estimatedEfficiency,
      },
    };

    const jsonString = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `sic461_${inputs.vout}v_${inputs.ioutMax}a_config.json`;
    link.click();
    URL.revokeObjectURL(url);
    showToast('Параметры и режимы успешно выгружены в JSON файл');
  };

  // Trigger file open dialog
  const handleImportJsonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  // Handle uploaded JSON file
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        const importedInputs = parsed.inputs || parsed;
        const inputModes = parsed.inputModes || {};
        const inputComponents = parsed.inputComponents || {};

        // Extract modes and components
        const voutMode =
          importedInputs.voutInputMode || inputModes.voutInputMode || 'voltage';
        const ssMode =
          importedInputs.softStartInputMode || inputModes.softStartInputMode || 'time';
        const uvloMode =
          importedInputs.uvloInputMode || inputModes.uvloInputMode || 'voltage';

        let rfb1 = Number(importedInputs.rfb1Kohm ?? inputComponents.rfb1Kohm ?? 52.5);
        let rfb2 = Number(importedInputs.rfb2Kohm ?? inputComponents.rfb2Kohm ?? 10.0);
        let vout = Number(importedInputs.vout ?? 5.0);
        if (voutMode === 'resistors') {
          vout = Number((0.800 * (1 + rfb1 / rfb2)).toFixed(3));
        } else {
          rfb1 = Number((rfb2 * (vout / 0.800 - 1)).toFixed(2));
        }

        let css = Number(importedInputs.cssNf ?? inputComponents.cssNf ?? 31.25);
        let tss = Number(importedInputs.tssMs ?? 5.0);
        if (ssMode === 'capacitor') {
          tss = Number(((css * 0.8) / 5).toFixed(3));
        } else {
          css = Number(((tss * 5) / 0.8).toFixed(2));
        }

        let ren1 = Number(importedInputs.ren1Kohm ?? inputComponents.ren1Kohm ?? 127.5);
        let ren2 = Number(importedInputs.ren2Kohm ?? inputComponents.ren2Kohm ?? 10.0);
        let vinStart = Number(importedInputs.vinStartUvlo ?? 16.5);
        if (uvloMode === 'resistors') {
          vinStart = Number((1.20 * (1 + ren1 / ren2)).toFixed(2));
        } else {
          ren1 = Number((ren2 * (vinStart / 1.20 - 1)).toFixed(2));
        }

        setInputs({
          vinNom: Number(importedInputs.vinNom ?? 24),
          vinMin: Number(importedInputs.vinMin ?? 18),
          vinMax: Number(importedInputs.vinMax ?? 32),
          vout,
          ioutMax: Number(importedInputs.ioutMax ?? 10),
          fswKhz: Number(importedInputs.fswKhz ?? 500),
          kind: Number(importedInputs.kind ?? 0.3),
          voutRippleMaxMv: Number(importedInputs.voutRippleMaxMv ?? 30),
          loadStepA: Number(importedInputs.loadStepA ?? 5),
          voltageOvershootMv: Number(importedInputs.voltageOvershootMv ?? 150),
          tssMs: tss,
          vinStartUvlo: vinStart,
          vinStopUvlo: Number((1.10 * (1 + ren1 / ren2)).toFixed(2)),
          voutInputMode: voutMode,
          softStartInputMode: ssMode,
          uvloInputMode: uvloMode,
          rfb1Kohm: rfb1,
          rfb2Kohm: rfb2,
          cssNf: css,
          ren1Kohm: ren1,
          ren2Kohm: ren2,
        });
        setSelectedPresetId('custom');
        showToast(`Параметры и режимы успешно загружены из "${file.name}"`);
      } catch (err) {
        showToast('Ошибка при чтении JSON: неверный формат');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 font-sans select-none overflow-hidden">
      {/* Hidden File Input for JSON Loading */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".json"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedPresetId={selectedPresetId}
        onSelectPreset={handleSelectPreset}
        onOpenPythonModal={() => setIsPythonModalOpen(true)}
        onExportJson={handleExportJson}
        onImportJsonClick={handleImportJsonClick}
        onResetDefaults={handleResetDefaults}
      />

      {/* Mobile Tab Switcher */}
      <div className="lg:hidden flex items-center justify-around bg-slate-900 border-b border-slate-800 p-2 text-xs">
        <button
          onClick={() => setActiveTab('schematic')}
          className={`px-3 py-1 rounded ${activeTab === 'schematic' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
        >
          Схема
        </button>
        <button
          onClick={() => setActiveTab('bom')}
          className={`px-3 py-1 rounded ${activeTab === 'bom' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
        >
          BOM спецификация
        </button>
        <button
          onClick={() => setActiveTab('analysis')}
          className={`px-3 py-1 rounded ${activeTab === 'analysis' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
        >
          Пульсации & КПД
        </button>
      </div>

      {/* Main Workspace: Split Console */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Left Control Column */}
        <InputPanel
          inputs={inputs}
          results={results}
          onChange={handleInputChange}
        />

        {/* Right Dynamic Stage View */}
        {activeTab === 'schematic' && (
          <SchematicView inputs={inputs} results={results} />
        )}
        {activeTab === 'bom' && (
          <BomTable
            bomItems={bomItems}
            projectName={`SiC461_${inputs.vout}V_${inputs.ioutMax}A`}
          />
        )}
        {activeTab === 'analysis' && (
          <WaveformChart inputs={inputs} results={results} />
        )}
      </div>

      {/* Standalone Python Script Modal */}
      <PythonExportModal
        isOpen={isPythonModalOpen}
        onClose={() => setIsPythonModalOpen(false)}
        inputs={inputs}
      />

      {/* Notification Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2 px-4 py-2.5 bg-slate-900 border border-cyan-500/80 text-white text-xs rounded-lg shadow-2xl backdrop-blur-md animate-fade-in font-medium">
          <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
