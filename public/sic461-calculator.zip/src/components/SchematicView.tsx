import React, { useState } from 'react';
import { CalculatorInputs, CalculatorResults } from '../types/calculator';
import { Info, CheckCircle2 } from 'lucide-react';

interface SchematicViewProps {
  inputs: CalculatorInputs;
  results: CalculatorResults;
}

export const SchematicView: React.FC<SchematicViewProps> = ({
  inputs,
  results,
}) => {
  const [highlighted, setHighlighted] = useState<string | null>(null);

  const getComponentDetail = (id: string) => {
    switch (id) {
      case 'L1':
        return {
          title: 'Силовой дроссель L1',
          value: `${results.lNominal.nominal} µH (расчетное: ${results.lCalcUh} µH)`,
          detail: `Рейтинг Isat ≥ ${(results.iPeak * 1.3).toFixed(1)} A, Irms ≥ ${(results.iRms * 1.15).toFixed(1)} A. Пульсации тока ΔIL = ${results.actualDeltaIL} A (${(results.actualKind * 100).toFixed(0)}% от Iout). Потери в меди DCR ≈ ${results.inductorDcrLossW} Вт.`,
        };
      case 'COUT':
        return {
          title: 'Выходная батарея конденсаторов COUT',
          value: `${results.coutQty} × ${results.coutSingleUf} µF (Суммарно: ${results.coutQty * results.coutSingleUf} µF)`,
          detail: `Мин. эффективная емкость: ${results.coutEffectiveMinUf} µF (по пульсациям ${results.coutRippleMinUf} µF, по набросу нагрузки ${results.coutTransientMinUf} µF). Расчетные пульсации Vout ≈ ${results.actualRippleMv} мВ. Учтено падение емкости керамики при постоянном смещении (DC-bias).`,
        };
      case 'CIN':
        return {
          title: 'Входные конденсаторы CIN',
          value: `${results.cinQty} × ${results.cinSingleUf} µF + 0.1 µF ВЧ`,
          detail: `Суммарно ${results.cinQty * results.cinSingleUf} µF. RMS ток через конденсаторы: ${results.cinRmsA} A. Рабочее напряжение ≥ ${Math.ceil(inputs.vinMax * 1.35)} В. Устанавливать вплотную к выводам VIN и PGND.`,
        };
      case 'RFB1':
        return {
          title: 'Верхний резистор делителя FB (RFB1)',
          value: `${results.rfbTop.nominal} kΩ (E96 1%, расчетное: ${results.rfbTop.theoretical} kΩ)`,
          detail: `Результирующий Vout: ${results.voutActual} В (погрешность ${results.voutErrorPercent > 0 ? '+' : ''}${results.voutErrorPercent}%). Мощность рассеяния пренебрежимо мала (< 1 мВт).`,
        };
      case 'RFB2':
        return {
          title: 'Нижний резистор делителя FB (RFB2)',
          value: `${results.rfbBottom.nominal} kΩ (E96 1%)`,
          detail: `Подключен к аналоговой земле AGND. Задает ток делителя 80 мкА для подавления помех на высокоомном входе FB.`,
        };
      case 'CFF':
        return {
          title: 'Конденсатор опережения CFF',
          value: results.cffPf ? `${results.cffPf.nominal} pF` : 'Не требуется',
          detail: `Компенсирует полюс выходного фильтра, расширяет полосу пропускания контура управления и увеличивает запас по фазе до > 55°. Рекомендуется диэлектрик C0G/NP0.`,
        };
      case 'CSS':
        return {
          title: 'Конденсатор мягкого старта CSS',
          value: `${results.cssNf.nominal} nF (E24)`,
          detail: `Заряжается внутренним источником тока Iss = 5 мкА. Обеспечивает плавное нарастание выходного напряжения без бросков пускового тока за время Tss ≈ ${results.actualTssMs} мс.`,
        };
      case 'RLIM':
        return {
          title: 'Резистор токового предела RLIM',
          value: `${results.rlimKohm.nominal} kΩ (E96 1%)`,
          detail: `Устанавливает порог поцикловой токовой защиты на уровне пикового тока ≈ ${results.ilimNominalA} А с безопасным запасом 25-30% от Ipeak.`,
        };
      case 'UVLO':
        return {
          title: 'Делитель разрешения / UVLO (REN1 / REN2)',
          value: `REN1: ${results.renTopKohm.nominal} kΩ / REN2: 10.0 kΩ`,
          detail: `Порог включения преобразователя Vin_start = ${results.actualVinStart} В, порог отключения Vin_stop = ${results.actualVinStop} В (внутренний гистерезис вывода EN 100 мВ).`,
        };
      case 'CBOOT':
        return {
          title: 'Бутстрепная накачка CBOOT + RBOOT',
          value: `CBOOT: 100 nF / RBOOT: 3.3 Ω`,
          detail: `Питает драйвер верхнего N-канального MOSFET. Резистор RBOOT снижает крутизну фронтов dV/dt в узле SW, подавляя ВЧ помехи (EMI) и звон.`,
        };
      case 'VDD':
        return {
          title: 'Внутренний регулятор VDD',
          value: `CVDD: 4.7 µF (керамика X7R, 10V+)`,
          detail: `Питает внутреннюю логику и драйвер нижнего ключа напряжением 5В. Требует локальной развязки керамическим конденсатором.`,
        };
      default:
        return null;
    }
  };

  const activeDetail = highlighted ? getComponentDetail(highlighted) : null;

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 p-5 overflow-y-auto">
      {/* Top summary card */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-slate-900 border border-slate-800 rounded-lg mb-4 text-xs">
        <div className="flex items-center gap-6">
          <div>
            <span className="text-slate-400 block text-[11px]">Входное напряжение:</span>
            <span className="font-mono text-white font-semibold">
              {inputs.vinMin}В .. <span className="text-cyan-400">{inputs.vinNom}В</span> .. {inputs.vinMax}В
            </span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Выходной режим:</span>
            <span className="font-mono text-emerald-400 font-bold text-sm">
              {results.voutActual} В @ {inputs.ioutMax} А
            </span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Индуктивность L1:</span>
            <span className="font-mono text-amber-300 font-bold text-sm">
              {results.lNominal.nominal} µH
            </span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Батарея COUT:</span>
            <span className="font-mono text-cyan-300 font-bold text-sm">
              {results.coutQty} × {results.coutSingleUf} µF
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-mono text-[11px]">Нажмите на компонент для подробностей</span>
        </div>
      </div>

      {/* SVG Circuit Schematic Canvas */}
      <div className="flex-1 relative bg-slate-900/90 border border-slate-800 rounded-lg p-3 min-h-[500px] flex items-center justify-center overflow-x-auto shadow-inner">
        <svg
          viewBox="0 0 1000 600"
          className="w-full max-w-[980px] h-auto select-none font-sans"
        >
          <defs>
            <linearGradient id="icGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#1e293b" />
              <stop offset="100%" stopColor="#0f172a" />
            </linearGradient>
            <marker
              id="dot"
              viewBox="0 0 10 10"
              refX="5"
              refY="5"
              markerWidth="4"
              markerHeight="4"
            >
              <circle cx="5" cy="5" r="4" fill="#0284c7" />
            </marker>
          </defs>

          {/* BACKGROUND GRID */}
          <pattern id="smallGrid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#1e293b" strokeWidth="0.5" />
          </pattern>
          <rect width="1000" height="600" fill="url(#smallGrid)" opacity="0.4" />

          {/* ===================== CENTRAL IC: SiC461 ===================== */}
          <g>
            <rect
              x="360"
              y="120"
              width="260"
              height="360"
              rx="8"
              fill="url(#icGrad)"
              stroke="#0284c7"
              strokeWidth="2"
            />
            {/* IC Orientation Notch */}
            <circle cx="380" cy="140" r="5" fill="#0284c7" opacity="0.7" />
            
            <text x="490" y="270" textAnchor="middle" fill="#ffffff" fontWeight="bold" fontSize="16" letterSpacing="1">
              Vishay SiC461
            </text>
            <text x="490" y="295" textAnchor="middle" fill="#38bdf8" fontSize="12" fontFamily="JetBrains Mono">
              microBUCK® 60V 10A
            </text>
            <text x="490" y="320" textAnchor="middle" fill="#64748b" fontSize="11" fontFamily="JetBrains Mono">
              PowerPAK MLP55-27L
            </text>

            {/* Left Pins */}
            {/* VIN Pin */}
            <line x1="320" y1="160" x2="360" y2="160" stroke="#38bdf8" strokeWidth="2" />
            <text x="370" y="165" fill="#94a3b8" fontSize="12" fontWeight="600" fontFamily="JetBrains Mono">VIN</text>

            {/* EN / UVLO Pin */}
            <line x1="320" y1="230" x2="360" y2="230" stroke="#94a3b8" strokeWidth="2" />
            <text x="370" y="235" fill="#94a3b8" fontSize="12" fontWeight="600" fontFamily="JetBrains Mono">EN</text>

            {/* SS (Soft Start) Pin */}
            <line x1="320" y1="300" x2="360" y2="300" stroke="#94a3b8" strokeWidth="2" />
            <text x="370" y="305" fill="#94a3b8" fontSize="12" fontWeight="600" fontFamily="JetBrains Mono">SS</text>

            {/* ILIM Pin */}
            <line x1="320" y1="370" x2="360" y2="370" stroke="#94a3b8" strokeWidth="2" />
            <text x="370" y="375" fill="#94a3b8" fontSize="12" fontWeight="600" fontFamily="JetBrains Mono">ILIM</text>

            {/* AGND Pin */}
            <line x1="320" y1="440" x2="360" y2="440" stroke="#64748b" strokeWidth="2" />
            <text x="370" y="445" fill="#94a3b8" fontSize="12" fontWeight="600" fontFamily="JetBrains Mono">AGND</text>

            {/* Right Pins */}
            {/* BOOT Pin */}
            <line x1="620" y1="160" x2="660" y2="160" stroke="#38bdf8" strokeWidth="2" />
            <text x="610" y="165" textAnchor="end" fill="#94a3b8" fontSize="12" fontWeight="600" fontFamily="JetBrains Mono">BOOT</text>

            {/* SW / PHASE Pin */}
            <line x1="620" y1="210" x2="680" y2="210" stroke="#38bdf8" strokeWidth="3" />
            <text x="610" y="215" textAnchor="end" fill="#38bdf8" fontSize="12" fontWeight="700" fontFamily="JetBrains Mono">SW</text>

            {/* VDD Pin */}
            <line x1="620" y1="290" x2="660" y2="290" stroke="#94a3b8" strokeWidth="2" />
            <text x="610" y="295" textAnchor="end" fill="#94a3b8" fontSize="12" fontWeight="600" fontFamily="JetBrains Mono">VDD</text>

            {/* FB Pin */}
            <line x1="620" y1="370" x2="660" y2="370" stroke="#a78bfa" strokeWidth="2" />
            <text x="610" y="375" textAnchor="end" fill="#a78bfa" fontSize="12" fontWeight="600" fontFamily="JetBrains Mono">FB</text>

            {/* PGOOD Pin */}
            <line x1="620" y1="440" x2="660" y2="440" stroke="#94a3b8" strokeWidth="2" />
            <text x="610" y="445" textAnchor="end" fill="#94a3b8" fontSize="12" fontWeight="600" fontFamily="JetBrains Mono">PGOOD</text>

            {/* Bottom: PGND Pin */}
            <line x1="490" y1="480" x2="490" y2="520" stroke="#64748b" strokeWidth="3" />
            <text x="490" y="470" textAnchor="middle" fill="#94a3b8" fontSize="12" fontWeight="600" fontFamily="JetBrains Mono">PGND</text>
          </g>

          {/* ===================== INPUT SECTION (LEFT) ===================== */}
          {/* Main VIN Rail */}
          <line x1="80" y1="160" x2="320" y2="160" stroke="#38bdf8" strokeWidth="3" />
          <circle cx="80" cy="160" r="4" fill="#38bdf8" />
          <text x="70" y="150" textAnchor="end" fill="#38bdf8" fontSize="13" fontWeight="bold">
            VIN ({inputs.vinNom}V)
          </text>
          <text x="70" y="170" textAnchor="end" fill="#64748b" fontSize="10" fontFamily="JetBrains Mono">
            {inputs.vinMin}V - {inputs.vinMax}V
          </text>

          {/* Input Capacitor (CIN) */}
          <g
            className="cursor-pointer group"
            onClick={() => setHighlighted('CIN')}
            onMouseEnter={() => setHighlighted('CIN')}
          >
            {/* T-junction */}
            <circle cx="180" cy="160" r="4" fill="#38bdf8" />
            <line x1="180" y1="160" x2="180" y2="230" stroke="#38bdf8" strokeWidth="2" />
            
            {/* Capacitor symbol */}
            <rect
              x="160"
              y="225"
              width="40"
              height="30"
              rx="4"
              fill={highlighted === 'CIN' ? '#0369a1' : '#1e293b'}
              stroke={highlighted === 'CIN' ? '#38bdf8' : '#475569'}
              strokeWidth="1.5"
            />
            <line x1="172" y1="237" x2="188" y2="237" stroke="#38bdf8" strokeWidth="2" />
            <line x1="172" y1="243" x2="188" y2="243" stroke="#38bdf8" strokeWidth="2" />
            
            <line x1="180" y1="255" x2="180" y2="300" stroke="#475569" strokeWidth="2" />
            {/* Ground symbol */}
            <line x1="170" y1="300" x2="190" y2="300" stroke="#64748b" strokeWidth="2" />
            <line x1="174" y1="305" x2="186" y2="305" stroke="#64748b" strokeWidth="1.5" />
            <line x1="177" y1="310" x2="183" y2="310" stroke="#64748b" strokeWidth="1" />

            <text x="180" y="215" textAnchor="middle" fill="#e2e8f0" fontSize="12" fontWeight="bold">CIN</text>
            <text x="180" y="275" textAnchor="middle" fill="#38bdf8" fontSize="11" fontWeight="600" fontFamily="JetBrains Mono">
              {results.cinQty}×{results.cinSingleUf}µF
            </text>
            <text x="180" y="288" textAnchor="middle" fill="#94a3b8" fontSize="9" fontFamily="JetBrains Mono">
              {results.cinRecommendedUf.voltageRating?.split(' ')[1] || '50V'}
            </text>
          </g>

          {/* UVLO Divider (REN1, REN2) */}
          <g
            className="cursor-pointer group"
            onClick={() => setHighlighted('UVLO')}
            onMouseEnter={() => setHighlighted('UVLO')}
          >
            <circle cx="260" cy="160" r="4" fill="#38bdf8" />
            <line x1="260" y1="160" x2="260" y2="230" stroke="#94a3b8" strokeWidth="2" />
            <line x1="260" y1="230" x2="320" y2="230" stroke="#94a3b8" strokeWidth="2" />

            {/* REN1 Box */}
            <rect
              x="248"
              y="180"
              width="24"
              height="35"
              fill={highlighted === 'UVLO' ? '#0369a1' : '#1e293b'}
              stroke="#64748b"
              strokeWidth="1.5"
            />
            <text x="235" y="200" textAnchor="end" fill="#e2e8f0" fontSize="11" fontWeight="bold">REN1</text>
            <text x="235" y="213" textAnchor="end" fill="#38bdf8" fontSize="10" fontFamily="JetBrains Mono">
              {results.renTopKohm.nominal}k
            </text>

            {/* REN2 Box */}
            <line x1="260" y1="230" x2="260" y2="290" stroke="#94a3b8" strokeWidth="2" />
            <rect
              x="248"
              y="245"
              width="24"
              height="35"
              fill={highlighted === 'UVLO' ? '#0369a1' : '#1e293b'}
              stroke="#64748b"
              strokeWidth="1.5"
            />
            <text x="235" y="265" textAnchor="end" fill="#e2e8f0" fontSize="11" fontWeight="bold">REN2</text>
            <text x="235" y="278" textAnchor="end" fill="#94a3b8" fontSize="10" fontFamily="JetBrains Mono">10.0k</text>

            {/* GND */}
            <line x1="260" y1="280" x2="260" y2="300" stroke="#64748b" strokeWidth="2" />
            <line x1="252" y1="300" x2="268" y2="300" stroke="#64748b" strokeWidth="2" />
            <line x1="255" y1="304" x2="265" y2="304" stroke="#64748b" strokeWidth="1.5" />
          </g>

          {/* Soft-Start Capacitor (CSS) */}
          <g
            className="cursor-pointer group"
            onClick={() => setHighlighted('CSS')}
            onMouseEnter={() => setHighlighted('CSS')}
          >
            <line x1="280" y1="300" x2="320" y2="300" stroke="#94a3b8" strokeWidth="2" />
            <line x1="280" y1="300" x2="280" y2="340" stroke="#94a3b8" strokeWidth="2" />
            
            <rect
              x="268"
              y="320"
              width="24"
              height="25"
              fill={highlighted === 'CSS' ? '#0369a1' : '#1e293b'}
              stroke="#64748b"
              strokeWidth="1.5"
            />
            <text x="255" y="333" textAnchor="end" fill="#e2e8f0" fontSize="11" fontWeight="bold">CSS</text>
            <text x="255" y="346" textAnchor="end" fill="#38bdf8" fontSize="10" fontFamily="JetBrains Mono">
              {results.cssNf.nominal}nF
            </text>

            <line x1="280" y1="345" x2="280" y2="365" stroke="#64748b" strokeWidth="2" />
            <line x1="272" y1="365" x2="288" y2="365" stroke="#64748b" strokeWidth="2" />
            <line x1="275" y1="369" x2="285" y2="369" stroke="#64748b" strokeWidth="1.5" />
          </g>

          {/* Current Limit Resistor (RLIM) */}
          <g
            className="cursor-pointer group"
            onClick={() => setHighlighted('RLIM')}
            onMouseEnter={() => setHighlighted('RLIM')}
          >
            <line x1="280" y1="370" x2="320" y2="370" stroke="#94a3b8" strokeWidth="2" />
            <line x1="280" y1="370" x2="280" y2="400" stroke="#94a3b8" strokeWidth="2" />
            
            <rect
              x="268"
              y="390"
              width="24"
              height="30"
              fill={highlighted === 'RLIM' ? '#0369a1' : '#1e293b'}
              stroke="#64748b"
              strokeWidth="1.5"
            />
            <text x="255" y="405" textAnchor="end" fill="#e2e8f0" fontSize="11" fontWeight="bold">RLIM</text>
            <text x="255" y="418" textAnchor="end" fill="#38bdf8" fontSize="10" fontFamily="JetBrains Mono">
              {results.rlimKohm.nominal}k
            </text>

            <line x1="280" y1="420" x2="280" y2="440" stroke="#64748b" strokeWidth="2" />
            <line x1="272" y1="440" x2="288" y2="440" stroke="#64748b" strokeWidth="2" />
            <line x1="275" y1="444" x2="285" y2="444" stroke="#64748b" strokeWidth="1.5" />
          </g>

          {/* ===================== OUTPUT SECTION (RIGHT) ===================== */}
          {/* SW to Inductor L1 */}
          <line x1="680" y1="210" x2="720" y2="210" stroke="#38bdf8" strokeWidth="3" />
          
          {/* Inductor L1 */}
          <g
            className="cursor-pointer group"
            onClick={() => setHighlighted('L1')}
            onMouseEnter={() => setHighlighted('L1')}
          >
            {/* Inductor Coils Representation */}
            <rect
              x="720"
              y="195"
              width="60"
              height="30"
              rx="6"
              fill={highlighted === 'L1' ? '#0369a1' : '#1e293b'}
              stroke={highlighted === 'L1' ? '#f59e0b' : '#38bdf8'}
              strokeWidth="2"
            />
            {/* Coil waves */}
            <path
              d="M 730 210 Q 737 198 745 210 Q 752 198 760 210 Q 767 198 775 210"
              fill="none"
              stroke="#f59e0b"
              strokeWidth="2.5"
            />
            <text x="750" y="185" textAnchor="middle" fill="#f59e0b" fontSize="13" fontWeight="bold">
              L1: {results.lNominal.nominal} µH
            </text>
            <text x="750" y="240" textAnchor="middle" fill="#94a3b8" fontSize="10" fontFamily="JetBrains Mono">
              Isat ≥ {(results.iPeak * 1.3).toFixed(1)}A
            </text>
          </g>

          {/* VOUT Main Rail */}
          <line x1="780" y1="210" x2="940" y2="210" stroke="#10b981" strokeWidth="3" />
          <circle cx="940" cy="210" r="4" fill="#10b981" />
          <text x="950" y="205" textAnchor="start" fill="#10b981" fontSize="14" fontWeight="bold">
            VOUT ({results.voutActual}V)
          </text>
          <text x="950" y="222" textAnchor="start" fill="#64748b" fontSize="11" fontFamily="JetBrains Mono">
            До {inputs.ioutMax}A (ΔV≈{results.actualRippleMv}mV)
          </text>

          {/* Output Capacitors (COUT) */}
          <g
            className="cursor-pointer group"
            onClick={() => setHighlighted('COUT')}
            onMouseEnter={() => setHighlighted('COUT')}
          >
            <circle cx="830" cy="210" r="4" fill="#10b981" />
            <line x1="830" y1="210" x2="830" y2="280" stroke="#10b981" strokeWidth="2" />
            
            <rect
              x="810"
              y="275"
              width="40"
              height="30"
              rx="4"
              fill={highlighted === 'COUT' ? '#0369a1' : '#1e293b'}
              stroke={highlighted === 'COUT' ? '#10b981' : '#475569'}
              strokeWidth="1.5"
            />
            <line x1="822" y1="287" x2="838" y2="287" stroke="#10b981" strokeWidth="2" />
            <line x1="822" y1="293" x2="838" y2="293" stroke="#10b981" strokeWidth="2" />

            <line x1="830" y1="305" x2="830" y2="340" stroke="#64748b" strokeWidth="2" />
            <line x1="820" y1="340" x2="840" y2="340" stroke="#64748b" strokeWidth="2" />
            <line x1="824" y1="345" x2="836" y2="345" stroke="#64748b" strokeWidth="1.5" />

            <text x="830" y="265" textAnchor="middle" fill="#e2e8f0" fontSize="12" fontWeight="bold">COUT</text>
            <text x="830" y="325" textAnchor="middle" fill="#10b981" fontSize="11" fontWeight="600" fontFamily="JetBrains Mono">
              {results.coutQty}×{results.coutSingleUf}µF
            </text>
          </g>

          {/* Feedback Divider (RFB1, RFB2, CFF) */}
          <g
            className="cursor-pointer group"
            onClick={() => setHighlighted('RFB1')}
            onMouseEnter={() => setHighlighted('RFB1')}
          >
            <circle cx="900" cy="210" r="4" fill="#10b981" />
            <line x1="900" y1="210" x2="900" y2="260" stroke="#a78bfa" strokeWidth="2" />
            
            {/* RFB1 Box */}
            <rect
              x="888"
              y="260"
              width="24"
              height="35"
              fill={highlighted === 'RFB1' ? '#4c1d95' : '#1e293b'}
              stroke="#a78bfa"
              strokeWidth="1.5"
            />
            <text x="920" y="275" textAnchor="start" fill="#e2e8f0" fontSize="11" fontWeight="bold">RFB1</text>
            <text x="920" y="290" textAnchor="start" fill="#a78bfa" fontSize="11" fontFamily="JetBrains Mono" fontWeight="600">
              {results.rfbTop.nominal} kΩ
            </text>

            {/* Optional CFF parallel */}
            {results.cffPf && (
              <g onClick={(e) => { e.stopPropagation(); setHighlighted('CFF'); }}>
                <path d="M 875 250 L 875 305" stroke="#a78bfa" strokeWidth="1" strokeDasharray="3,3" />
                <rect x="867" y="270" width="16" height="18" fill="#1e293b" stroke="#a78bfa" />
                <text x="860" y="283" textAnchor="end" fill="#c4b5fd" fontSize="9" fontFamily="JetBrains Mono">
                  CFF: {results.cffPf.nominal}pF
                </text>
              </g>
            )}

            {/* Trace to FB pin */}
            <circle cx="900" cy="320" r="4" fill="#a78bfa" />
            <line x1="900" y1="295" x2="900" y2="370" stroke="#a78bfa" strokeWidth="2" />
            <line x1="900" y1="370" x2="660" y2="370" stroke="#a78bfa" strokeWidth="2" />

            {/* RFB2 Box */}
            <rect
              x="888"
              y="390"
              width="24"
              height="35"
              fill={highlighted === 'RFB2' ? '#4c1d95' : '#1e293b'}
              stroke="#a78bfa"
              strokeWidth="1.5"
              onClick={(e) => { e.stopPropagation(); setHighlighted('RFB2'); }}
            />
            <text x="920" y="405" textAnchor="start" fill="#e2e8f0" fontSize="11" fontWeight="bold">RFB2</text>
            <text x="920" y="420" textAnchor="start" fill="#a78bfa" fontSize="11" fontFamily="JetBrains Mono" fontWeight="600">
              {results.rfbBottom.nominal} kΩ
            </text>

            {/* GND */}
            <line x1="900" y1="425" x2="900" y2="450" stroke="#64748b" strokeWidth="2" />
            <line x1="892" y1="450" x2="908" y2="450" stroke="#64748b" strokeWidth="2" />
            <line x1="895" y1="454" x2="905" y2="454" stroke="#64748b" strokeWidth="1.5" />
          </g>

          {/* Bootstrap Loop (BOOT to SW) */}
          <g
            className="cursor-pointer group"
            onClick={() => setHighlighted('CBOOT')}
            onMouseEnter={() => setHighlighted('CBOOT')}
          >
            <line x1="660" y1="160" x2="700" y2="160" stroke="#38bdf8" strokeWidth="2" />
            <line x1="700" y1="160" x2="700" y2="185" stroke="#38bdf8" strokeWidth="2" />
            
            <rect
              x="690"
              y="170"
              width="20"
              height="20"
              fill={highlighted === 'CBOOT' ? '#0369a1' : '#1e293b'}
              stroke="#38bdf8"
              strokeWidth="1.5"
            />
            <text x="700" y="150" textAnchor="middle" fill="#38bdf8" fontSize="10" fontFamily="JetBrains Mono" fontWeight="bold">
              CBOOT: 100nF
            </text>

            <line x1="700" y1="190" x2="700" y2="210" stroke="#38bdf8" strokeWidth="2" />
            <circle cx="700" cy="210" r="3" fill="#38bdf8" />
          </g>

          {/* VDD Capacitor */}
          <g
            className="cursor-pointer group"
            onClick={() => setHighlighted('VDD')}
            onMouseEnter={() => setHighlighted('VDD')}
          >
            <line x1="660" y1="290" x2="700" y2="290" stroke="#94a3b8" strokeWidth="2" />
            <line x1="700" y1="290" x2="700" y2="320" stroke="#94a3b8" strokeWidth="2" />
            
            <rect
              x="690"
              y="310"
              width="20"
              height="20"
              fill={highlighted === 'VDD' ? '#0369a1' : '#1e293b'}
              stroke="#64748b"
              strokeWidth="1.5"
            />
            <text x="715" y="325" textAnchor="start" fill="#e2e8f0" fontSize="10" fontWeight="bold">CVDD</text>
            <text x="715" y="338" textAnchor="start" fill="#38bdf8" fontSize="10" fontFamily="JetBrains Mono">
              4.7 µF
            </text>

            <line x1="700" y1="330" x2="700" y2="350" stroke="#64748b" strokeWidth="2" />
            <line x1="693" y1="350" x2="707" y2="350" stroke="#64748b" strokeWidth="2" />
          </g>

          {/* PGND Ground Plane */}
          <line x1="475" y1="520" x2="505" y2="520" stroke="#64748b" strokeWidth="3" />
          <line x1="480" y1="526" x2="500" y2="526" stroke="#64748b" strokeWidth="2" />
          <line x1="485" y1="531" x2="495" y2="531" stroke="#64748b" strokeWidth="1" />
          <text x="490" y="550" textAnchor="middle" fill="#64748b" fontSize="11" fontFamily="JetBrains Mono">
            Силовая земля (PGND)
          </text>
        </svg>

        {/* Floating Detail Overlay when clicked/hovered */}
        {activeDetail && (
          <div className="absolute bottom-4 left-4 right-4 bg-slate-900/95 border border-cyan-500/80 rounded-lg p-3 text-xs shadow-xl backdrop-blur-sm animate-fade-in flex items-start justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span className="font-bold text-white text-sm">
                  {activeDetail.title}
                </span>
                <span className="font-mono text-cyan-300 font-semibold px-2 py-0.5 bg-cyan-950 rounded border border-cyan-800">
                  {activeDetail.value}
                </span>
              </div>
              <p className="text-slate-300 font-sans leading-relaxed">
                {activeDetail.detail}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setHighlighted(null)}
              className="text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800 text-[11px]"
            >
              Закрыть
            </button>
          </div>
        )}
      </div>

      {/* Component quick badges row */}
      <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
        {[
          { id: 'L1', label: 'Дроссель L1', val: `${results.lNominal.nominal} µH` },
          { id: 'COUT', label: 'Выход COUT', val: `${results.coutQty}×${results.coutSingleUf} µF` },
          { id: 'CIN', label: 'Вход CIN', val: `${results.cinQty}×${results.cinSingleUf} µF` },
          { id: 'RFB1', label: 'Делитель RFB1', val: `${results.rfbTop.nominal} kΩ` },
          { id: 'CSS', label: 'Старт CSS', val: `${results.cssNf.nominal} nF` },
          { id: 'RLIM', label: 'Ток RLIM', val: `${results.rlimKohm.nominal} kΩ` },
        ].map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setHighlighted(c.id)}
            className={`p-2 rounded border text-left transition-colors ${
              highlighted === c.id
                ? 'bg-cyan-950/80 border-cyan-500 text-cyan-200'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
            }`}
          >
            <span className="text-[10px] text-slate-400 block">{c.label}</span>
            <span className="text-xs font-mono font-bold text-white">{c.val}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
