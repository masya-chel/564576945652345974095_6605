import React, { useState, useEffect, useRef } from 'react';
import {
  CalculatorInputs,
  CalculatorResults,
  VoutInputMode,
  SoftStartInputMode,
  UvloInputMode,
} from '../types/calculator';
import { AlertTriangle, Sliders } from 'lucide-react';

interface ManualNumericInputProps {
  label: string;
  value: number;
  unit?: string;
  onChange: (val: number) => void;
  min?: number;
  max?: number;
  hint?: string;
  colorScheme?: 'cyan' | 'emerald' | 'amber' | 'purple' | 'default';
  disabled?: boolean;
}

const ManualNumericInput: React.FC<ManualNumericInputProps> = ({
  label,
  value,
  unit,
  onChange,
  min,
  max,
  hint,
  colorScheme = 'default',
  disabled = false,
}) => {
  const [text, setText] = useState<string>(String(value));
  const isFocusedRef = useRef(false);

  useEffect(() => {
    if (!isFocusedRef.current) {
      setText(String(value));
    }
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(',', '.');
    if (raw === '' || /^\d*\.?\d*$/.test(raw)) {
      setText(raw);
      const parsed = parseFloat(raw);
      if (!isNaN(parsed)) {
        onChange(parsed);
      }
    }
  };

  const handleBlur = () => {
    isFocusedRef.current = false;
    const parsed = parseFloat(text);
    if (isNaN(parsed) || text.trim() === '' || parsed <= 0) {
      setText(String(value));
    } else {
      setText(String(parsed));
      onChange(parsed);
    }
  };

  const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
    if (disabled) return;
    isFocusedRef.current = true;
    e.target.select();
  };

  const getBorderColor = () => {
    if (disabled) {
      return 'border-slate-800 bg-slate-950/40 text-slate-400 cursor-not-allowed opacity-80';
    }
    switch (colorScheme) {
      case 'cyan':
        return 'border-cyan-700/80 focus:border-cyan-400 text-cyan-300 bg-slate-950';
      case 'emerald':
        return 'border-emerald-700/80 focus:border-emerald-400 text-emerald-400 font-bold bg-slate-950';
      case 'amber':
        return 'border-amber-700/80 focus:border-amber-400 text-amber-400 font-bold bg-slate-950';
      case 'purple':
        return 'border-purple-700/80 focus:border-purple-400 text-purple-300 font-semibold bg-slate-950';
      default:
        return 'border-slate-700 focus:border-cyan-500 text-slate-100 bg-slate-950';
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className={`text-[11px] ${disabled ? 'text-slate-400' : 'text-slate-300'}`}>
          {label}
        </span>
        {unit && (
          <span className="text-[11px] font-mono text-slate-400 ml-1">
            {unit}
          </span>
        )}
      </div>
      <div className="relative">
        <input
          type="text"
          inputMode="decimal"
          disabled={disabled}
          value={text}
          onChange={handleChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          className={`w-full border rounded px-2.5 py-1.5 text-xs font-mono focus:outline-none transition-colors ${getBorderColor()}`}
        />
      </div>
      {hint && <span className="text-[10px] text-slate-400 block mt-0.5">{hint}</span>}
    </div>
  );
};

interface InputPanelProps {
  inputs: CalculatorInputs;
  results: CalculatorResults;
  onChange: <K extends keyof CalculatorInputs>(field: K, value: CalculatorInputs[K]) => void;
}

export const InputPanel: React.FC<InputPanelProps> = ({
  inputs,
  results,
  onChange,
}) => {
  // Exact physical turn-off threshold and hysteresis of SiC461
  const actualVinStop = Number(
    (1.10 * (1 + inputs.ren1Kohm / inputs.ren2Kohm)).toFixed(2)
  );
  const actualHysteresis = Number(
    (inputs.vinStartUvlo - actualVinStop).toFixed(2)
  );

  return (
    <div className="w-full lg:w-96 shrink-0 bg-slate-900 border-r border-slate-800 p-5 overflow-y-auto space-y-6 text-slate-200">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-semibold tracking-wide text-white uppercase">
            Параметры источника
          </h2>
        </div>
        <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
          SiC461 (10A)
        </span>
      </div>

      {/* Warnings Banner if any */}
      {results.warnings.length > 0 && (
        <div className="p-3 bg-amber-950/40 border border-amber-800/80 rounded-lg text-xs space-y-1.5">
          <div className="flex items-center gap-1.5 font-medium text-amber-300">
            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
            <span>Внимание: ограничения кремния</span>
          </div>
          <ul className="list-disc pl-4 space-y-1 text-amber-200/90 font-sans">
            {results.warnings.map((w, idx) => (
              <li key={idx}>{w}</li>
            ))}
          </ul>
        </div>
      )}

      {/* 1. Входное напряжение (Vin) */}
      <div className="space-y-3">
        <label className="text-xs font-semibold text-slate-400 tracking-wider uppercase block">
          Входное напряжение (VIN)
        </label>
        
        <div className="grid grid-cols-3 gap-2">
          <ManualNumericInput
            label="Мин. (В)"
            value={inputs.vinMin}
            min={4.5}
            max={60}
            onChange={(val) => onChange('vinMin', val)}
          />
          <ManualNumericInput
            label="Ном. (В)"
            value={inputs.vinNom}
            min={4.5}
            max={60}
            colorScheme="cyan"
            onChange={(val) => onChange('vinNom', val)}
          />
          <ManualNumericInput
            label="Макс. (В)"
            value={inputs.vinMax}
            min={4.5}
            max={60}
            onChange={(val) => onChange('vinMax', val)}
          />
        </div>
        <p className="text-[11px] text-slate-400">
          Предельный рабочий диапазон SiC461: 4.5В – 60В
        </p>
      </div>

      {/* 2. Выходное напряжение и делитель обратной связи (VOUT & RFB) */}
      <div className="space-y-3 pt-3 border-t border-slate-800">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-slate-400 tracking-wider uppercase block">
            Выходная цепь (VOUT & RFB)
          </label>
          <span className="text-[10px] font-mono text-emerald-400">
            Vref = 0.800 В
          </span>
        </div>

        {/* Radio Button Selector: Mode of Definition */}
        <div className="p-2 bg-slate-950/70 border border-slate-800 rounded-md space-y-1 text-xs">
          <span className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
            Способ задания выходного напряжения:
          </span>
          <div className="grid grid-cols-2 gap-2">
            <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-slate-300 hover:text-white">
              <input
                type="radio"
                name="voutInputMode"
                value="voltage"
                checked={inputs.voutInputMode === 'voltage'}
                onChange={() => onChange('voutInputMode', 'voltage')}
                className="accent-emerald-500 cursor-pointer"
              />
              <span>По числу Vout (В)</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-slate-300 hover:text-white">
              <input
                type="radio"
                name="voutInputMode"
                value="resistors"
                checked={inputs.voutInputMode === 'resistors'}
                onChange={() => onChange('voutInputMode', 'resistors')}
                className="accent-emerald-500 cursor-pointer"
              />
              <span>По резисторам (кОм)</span>
            </label>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <ManualNumericInput
            label="Напряжение Vout"
            unit="В"
            value={inputs.vout}
            min={0.8}
            max={55}
            colorScheme={inputs.voutInputMode === 'voltage' ? 'emerald' : 'default'}
            disabled={inputs.voutInputMode === 'resistors'}
            hint={
              inputs.voutInputMode === 'voltage'
                ? `Стандарт E96: RFB1 = ${results.rfbTop.nominal} кОм`
                : 'Рассчитано из RFB1 / RFB2'
            }
            onChange={(val) => {
              // Voltage is defining -> update vout and sync rfb1
              onChange('vout', val);
              const syncedRfb1 = Number((inputs.rfb2Kohm * (val / 0.800 - 1)).toFixed(2));
              onChange('rfb1Kohm', syncedRfb1);
            }}
          />

          <ManualNumericInput
            label="Макс. ток Iout"
            unit="А"
            value={inputs.ioutMax}
            min={0.1}
            max={10.0}
            colorScheme="amber"
            onChange={(val) => onChange('ioutMax', val)}
          />
        </div>

        {/* Resistor Divider RFB1 & RFB2 */}
        <div className={`p-2.5 rounded-lg border transition-colors space-y-2 ${
          inputs.voutInputMode === 'resistors'
            ? 'bg-purple-950/30 border-purple-800/80'
            : 'bg-slate-950/60 border-slate-800'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-mono text-slate-400">
              Резисторы делителя обратной связи:
            </span>
            {inputs.voutInputMode === 'resistors' && (
              <span className="text-[10px] font-mono text-purple-300 font-semibold px-1.5 py-0.5 rounded bg-purple-900/60">
                Задающий режим
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <ManualNumericInput
              label="Верхний RFB1"
              unit="кОм"
              value={inputs.rfb1Kohm}
              colorScheme={inputs.voutInputMode === 'resistors' ? 'purple' : 'default'}
              disabled={inputs.voutInputMode === 'voltage'}
              hint={`Ближайший E96: ${results.rfbTop.nominal} кОм`}
              onChange={(newRfb1) => {
                onChange('rfb1Kohm', newRfb1);
                // Resistors define Vout = 0.8 * (1 + RFB1 / RFB2)
                const newVout = Number((0.800 * (1 + newRfb1 / inputs.rfb2Kohm)).toFixed(3));
                onChange('vout', newVout);
              }}
            />

            <ManualNumericInput
              label="Нижний RFB2"
              unit="кОм"
              value={inputs.rfb2Kohm}
              colorScheme={inputs.voutInputMode === 'resistors' ? 'purple' : 'default'}
              disabled={inputs.voutInputMode === 'voltage'}
              hint="Стандартно 10.0 кОм"
              onChange={(newRfb2) => {
                onChange('rfb2Kohm', newRfb2);
                if (newRfb2 > 0) {
                  const newVout = Number((0.800 * (1 + inputs.rfb1Kohm / newRfb2)).toFixed(3));
                  onChange('vout', newVout);
                }
              }}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <ManualNumericInput
            label="Пульсации Vout"
            unit="мВ"
            value={inputs.voutRippleMaxMv}
            min={5}
            max={500}
            hint={`${((inputs.voutRippleMaxMv / (inputs.vout * 1000)) * 100).toFixed(1)}% от Vout`}
            onChange={(val) => onChange('voutRippleMaxMv', val)}
          />

          <ManualNumericInput
            label="Шаг тока ΔIstep"
            unit="А"
            value={inputs.loadStepA}
            min={0.1}
            max={inputs.ioutMax}
            hint="Для расчета Cout"
            onChange={(val) => onChange('loadStepA', val)}
          />
        </div>

        <div>
          <ManualNumericInput
            label="Макс. просадка при набросе"
            unit="мВ"
            value={inputs.voltageOvershootMv}
            min={10}
            max={1000}
            onChange={(val) => onChange('voltageOvershootMv', val)}
          />
        </div>
      </div>

      {/* 3. Частота коммутации (Ручной ввод в кГц) и коэффициент пульсаций */}
      <div className="space-y-3 pt-3 border-t border-slate-800">
        <label className="text-xs font-semibold text-slate-400 tracking-wider uppercase block">
          Частота и режим дросселя
        </label>

        <div>
          <ManualNumericInput
            label="Рабочая частота коммутации Fsw"
            unit="кГц"
            value={inputs.fswKhz}
            min={100}
            max={2000}
            colorScheme="cyan"
            hint="Диапазон SiC461: от 100 до 2000 кГц (вводится вручную числом)"
            onChange={(val) => onChange('fswKhz', val)}
          />
        </div>

        <div>
          <ManualNumericInput
            label="Коэффициент пульсаций дросселя Kind (ΔIL / Iout)"
            value={inputs.kind}
            min={0.1}
            max={0.8}
            hint="Рекомендация: 0.2 .. 0.4 (по умолчанию 0.3)"
            onChange={(val) => onChange('kind', val)}
          />
        </div>
      </div>

      {/* 4. Софт-старт */}
      <div className="space-y-3 pt-3 border-t border-slate-800">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-slate-400 tracking-wider uppercase block">
            Софт-старт
          </label>
          <span className="text-[10px] font-mono text-cyan-400">
            Iss = 5 µA · Vref = 0.8В
          </span>
        </div>

        {/* Radio Button Selector: Mode of Definition */}
        <div className="p-2 bg-slate-950/70 border border-slate-800 rounded-md space-y-1 text-xs">
          <span className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
            Способ задания софт-старта:
          </span>
          <div className="grid grid-cols-2 gap-2">
            <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-slate-300 hover:text-white">
              <input
                type="radio"
                name="softStartInputMode"
                value="time"
                checked={inputs.softStartInputMode === 'time'}
                onChange={() => onChange('softStartInputMode', 'time')}
                className="accent-cyan-500 cursor-pointer"
              />
              <span>По времени Tss (мс)</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-slate-300 hover:text-white">
              <input
                type="radio"
                name="softStartInputMode"
                value="capacitor"
                checked={inputs.softStartInputMode === 'capacitor'}
                onChange={() => onChange('softStartInputMode', 'capacitor')}
                className="accent-cyan-500 cursor-pointer"
              />
              <span>По номиналу CSS (нФ)</span>
            </label>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <ManualNumericInput
            label="Время старта Tss"
            unit="мс"
            value={inputs.tssMs}
            min={0.1}
            max={100}
            colorScheme={inputs.softStartInputMode === 'time' ? 'cyan' : 'default'}
            disabled={inputs.softStartInputMode === 'capacitor'}
            hint={
              inputs.softStartInputMode === 'time'
                ? `Стандарт E24: ${results.cssNf.nominal} нФ`
                : 'Рассчитано из CSS'
            }
            onChange={(val) => {
              onChange('tssMs', val);
              const syncedCss = Number(((val * 5) / 0.8).toFixed(2));
              onChange('cssNf', syncedCss);
            }}
          />

          <ManualNumericInput
            label="Номинал конденсатора CSS"
            unit="нФ"
            value={inputs.cssNf}
            min={0.1}
            max={1000}
            colorScheme={inputs.softStartInputMode === 'capacitor' ? 'cyan' : 'default'}
            disabled={inputs.softStartInputMode === 'time'}
            hint={
              inputs.softStartInputMode === 'capacitor'
                ? `Дает Tss = ${Number(((inputs.cssNf * 0.8) / 5).toFixed(2))} мс`
                : `Стандарт E24: ${results.cssNf.nominal} нФ`
            }
            onChange={(valNf) => {
              onChange('cssNf', valNf);
              // Capacitor defines Tss: Tss = Css * 0.8 / 5
              const calculatedTss = Number(((valNf * 0.8) / 5).toFixed(3));
              onChange('tssMs', calculatedTss);
            }}
          />
        </div>
      </div>

      {/* 5. Защита по входу (UVLO / EN) */}
      <div className="space-y-3 pt-3 border-t border-slate-800">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-slate-400 tracking-wider uppercase block">
            Защита по входу (UVLO / EN)
          </label>
          <span className="text-[10px] font-mono text-cyan-400">
            Ven_rise = 1.20В · Ven_fall = 1.10В
          </span>
        </div>

        {/* Radio Button Selector: Mode of Definition */}
        <div className="p-2 bg-slate-950/70 border border-slate-800 rounded-md space-y-1 text-xs">
          <span className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
            Способ задания порога включения:
          </span>
          <div className="grid grid-cols-2 gap-2">
            <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-slate-300 hover:text-white">
              <input
                type="radio"
                name="uvloInputMode"
                value="voltage"
                checked={inputs.uvloInputMode === 'voltage'}
                onChange={() => onChange('uvloInputMode', 'voltage')}
                className="accent-cyan-500 cursor-pointer"
              />
              <span>По напряжению (В)</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-slate-300 hover:text-white">
              <input
                type="radio"
                name="uvloInputMode"
                value="resistors"
                checked={inputs.uvloInputMode === 'resistors'}
                onChange={() => onChange('uvloInputMode', 'resistors')}
                className="accent-cyan-500 cursor-pointer"
              />
              <span>По резисторам (кОм)</span>
            </label>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <ManualNumericInput
            label="Порог старта Vin_start"
            unit="В"
            value={inputs.vinStartUvlo}
            min={4.5}
            colorScheme={inputs.uvloInputMode === 'voltage' ? 'cyan' : 'default'}
            disabled={inputs.uvloInputMode === 'resistors'}
            hint={
              inputs.uvloInputMode === 'voltage'
                ? `Стандарт E96: REN1 = ${results.renTopKohm.nominal} кОм`
                : 'Рассчитано из REN1/REN2'
            }
            onChange={(val) => {
              onChange('vinStartUvlo', val);
              const syncedRen1 = Number((inputs.ren2Kohm * (val / 1.20 - 1)).toFixed(2));
              onChange('ren1Kohm', syncedRen1);
            }}
          />

          <ManualNumericInput
            label="Верхний резистор REN1"
            unit="кОм"
            value={inputs.ren1Kohm}
            colorScheme={inputs.uvloInputMode === 'resistors' ? 'cyan' : 'default'}
            disabled={inputs.uvloInputMode === 'voltage'}
            hint={`Ближайший E96: ${results.renTopKohm.nominal} кОм`}
            onChange={(newRen1) => {
              onChange('ren1Kohm', newRen1);
              // Resistors define Vin_start = 1.20 * (1 + REN1 / REN2)
              const newVinStart = Number((1.20 * (1 + newRen1 / inputs.ren2Kohm)).toFixed(2));
              onChange('vinStartUvlo', newVinStart);
            }}
          />
        </div>

        <div className="p-2.5 bg-slate-950/70 border border-slate-800 rounded-lg text-xs space-y-1.5 font-mono">
          <div className="flex items-center justify-between text-slate-400">
            <span>Нижний резистор REN2 к AGND:</span>
            <span className="text-slate-200 font-bold">{inputs.ren2Kohm} кОм</span>
          </div>
          <div className="flex items-center justify-between text-slate-400">
            <span>Порог отключения Vin_stop:</span>
            <span className="text-slate-200 font-bold">{actualVinStop} В</span>
          </div>
          <div className="flex items-center justify-between text-slate-400">
            <span>Физический гистерезис кремния:</span>
            <span className="text-emerald-400 font-bold">
              {actualHysteresis} В
            </span>
          </div>
        </div>
      </div>

      {/* Quick Summary Badge */}
      <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80 space-y-1.5 text-xs font-mono">
        <div className="flex items-center justify-between text-slate-400">
          <span>Duty Cycle (ном):</span>
          <span className="text-slate-200 font-bold">
            {(results.dutyNom * 100).toFixed(1)} %
          </span>
        </div>
        <div className="flex items-center justify-between text-slate-400">
          <span>Время t_on (мин):</span>
          <span
            className={
              results.tonMinWarning
                ? 'text-rose-400 font-bold'
                : 'text-emerald-400 font-medium'
            }
          >
            {results.tonNs} нс
          </span>
        </div>
        <div className="flex items-center justify-between text-slate-400">
          <span>Оценка КПД:</span>
          <span className="text-cyan-400 font-bold">
            ~ {results.estimatedEfficiency} %
          </span>
        </div>
      </div>
    </div>
  );
};
