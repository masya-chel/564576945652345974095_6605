import {
  CalculatorInputs,
  CalculatorResults,
  BomItem,
  StandardComponent,
} from '../types/calculator';
import {
  findNearestESeries,
  findCeilESeries,
  formatValue,
} from './eSeries';

export const SIC461_LIMITS = {
  VIN_MIN: 4.5,
  VIN_MAX: 60.0,
  VOUT_MIN: 0.8,
  VREF: 0.800,
  IOUT_MAX: 10.0,
  FSW_MIN_KHZ: 100,
  FSW_MAX_KHZ: 2000,
  TON_MIN_NS: 60,
  TOFF_MIN_NS: 80,
  ISS_UA: 5.0, // Soft-start charging current in µA
  VEN_RISING: 1.20,
  VEN_FALLING: 1.10,
  RDS_ON_HIGH_MOHM: 27,
  RDS_ON_LOW_MOHM: 12,
};

/**
 * Executes full design sizing calculations for Vishay SiC461 synchronous buck regulator
 */
export function calculateSiC461(inputs: CalculatorInputs): CalculatorResults {
  const warnings: string[] = [];
  const {
    vinNom,
    vinMin,
    vinMax,
    vout,
    ioutMax,
    fswKhz,
    kind,
    voutRippleMaxMv,
    loadStepA,
    voltageOvershootMv,
    tssMs,
    vinStartUvlo,
    vinStopUvlo,
  } = inputs;

  const fsw = fswKhz * 1000; // Hz

  // 1. Validations against SiC461 Silicon Limits
  if (vinMin < SIC461_LIMITS.VIN_MIN) {
    warnings.push(`Входное напряжение ${vinMin}В ниже минимального рабочего порога SiC461 (4.5В).`);
  }
  if (vinMax > SIC461_LIMITS.VIN_MAX) {
    warnings.push(`Входное напряжение ${vinMax}В превышает абсолютный максимум SiC461 (60В).`);
  }
  if (vout < SIC461_LIMITS.VREF) {
    warnings.push(`Выходное напряжение ${vout}В не может быть ниже опорного напряжения Vref (0.8В).`);
  }
  if (ioutMax > SIC461_LIMITS.IOUT_MAX) {
    warnings.push(`Выходной ток ${ioutMax}А превышает номинал SiC461 (10А). Рекомендуется SiC461 на ток до 10А.`);
  }

  // 2. Duty Cycle & Timing
  const estEfficiency = 0.92;
  const dutyNom = Math.min(0.95, vout / (vinNom * estEfficiency));
  const dutyMin = Math.min(0.95, vout / (vinMax * estEfficiency));
  const dutyMax = Math.min(0.95, vout / (vinMin * estEfficiency));

  const tswNs = (1 / fsw) * 1e9;
  const tonNs = dutyMin * tswNs; // Shortest pulse occurs at maximum Vin
  const toffNs = (1 - dutyMax) * tswNs; // Shortest off-time occurs at minimum Vin

  const tonMinWarning = tonNs < SIC461_LIMITS.TON_MIN_NS;
  const toffMinWarning = toffNs < SIC461_LIMITS.TOFF_MIN_NS;

  if (tonMinWarning) {
    warnings.push(
      `Время включения t_on (${tonNs.toFixed(1)} нс) меньше предельного t_on_min (60 нс). Уменьшите частоту коммутации Fsw.`
    );
  }
  if (toffMinWarning) {
    warnings.push(
      `Время выключения t_off (${toffNs.toFixed(1)} нс) меньше предельного t_off_min (80 нс). Превышен максимальный коэффициент заполнения.`
    );
  }

  // 3. Inductor Calculation
  const deltaILTarget = kind * ioutMax;
  // Vishay SiC461 Datasheet equation:
  // L = (Vout * (Vin_max - Vout)) / (Vin_max * fsw * deltaIL)
  const lCalcH = (vout * (vinMax - vout)) / (vinMax * fsw * deltaILTarget);
  const lCalcUh = lCalcH * 1e6;

  // Find nearest standard inductor in E24
  const lStandard = findNearestESeries(lCalcUh, 'E24');
  const lNominalUh = lStandard.nominal;
  const lNominalH = lNominalUh * 1e-6;

  // Actual ripple with chosen nominal inductor
  const actualDeltaIL = (vout * (vinMax - vout)) / (vinMax * fsw * lNominalH);
  const actualKind = actualDeltaIL / ioutMax;
  const iPeak = ioutMax + actualDeltaIL / 2;
  const iValley = Math.max(0, ioutMax - actualDeltaIL / 2);
  const iRms = Math.sqrt(Math.pow(ioutMax, 2) + Math.pow(actualDeltaIL, 2) / 12);

  const lComponent: StandardComponent = {
    theoretical: Number(lCalcUh.toFixed(3)),
    nominal: lNominalUh,
    unit: 'µH',
    formatted: `${lNominalUh} µH`,
    series: 'E24',
    errorPercent: lStandard.errorPercent,
    currentRating: `Isat ≥ ${(iPeak * 1.3).toFixed(1)} A, Irms ≥ ${(iRms * 1.15).toFixed(1)} A`,
    packageRecommendation: 'Экранированный силовой дроссель (DCR < 15 мОм)',
  };

  // 4. Output Capacitance (Cout)
  const voutRippleV = voutRippleMaxMv / 1000;
  // Ripple requirement: Cout >= deltaIL / (8 * fsw * deltaVout)
  const coutRippleMinF = actualDeltaIL / (8 * fsw * voutRippleV);
  const coutRippleMinUf = coutRippleMinF * 1e6;

  // Transient overshoot/undershoot requirement for load step:
  // Cout >= (L * (deltaIstep)^2) / (2 * Vout * deltaV_overshoot)
  const vOvershootV = voltageOvershootMv / 1000;
  const coutTransientMinF =
    (lNominalH * Math.pow(loadStepA, 2)) / (2 * vout * vOvershootV);
  const coutTransientMinUf = coutTransientMinF * 1e6;

  const coutEffectiveMinUf = Math.max(coutRippleMinUf, coutTransientMinUf);
  // Account for ceramic MLCC DC-bias derating (typically ~40% loss at rated voltage)
  const coutNominalTargetUf = coutEffectiveMinUf / 0.6;
  const coutStandard = findCeilESeries(coutNominalTargetUf, 'E24');

  // Multi-capacitor arrangement recommendation (e.g. 22µF or 47µF units)
  let singleCoutUf = 22;
  if (coutStandard.nominal > 80) singleCoutUf = 47;
  if (coutStandard.nominal > 200) singleCoutUf = 100;
  const coutQty = Math.max(2, Math.ceil(coutStandard.nominal / singleCoutUf));
  const totalCoutActualUf = coutQty * singleCoutUf;

  const actualRippleMv =
    ((actualDeltaIL / (8 * fsw * (totalCoutActualUf * 0.65 * 1e-6))) * 1000);

  const coutComponent: StandardComponent = {
    theoretical: Number(coutEffectiveMinUf.toFixed(1)),
    nominal: totalCoutActualUf,
    unit: 'µF',
    formatted: `${coutQty} × ${singleCoutUf} µF (${totalCoutActualUf} µF суммарно)`,
    series: 'E24',
    errorPercent: Number((((totalCoutActualUf - coutEffectiveMinUf) / coutEffectiveMinUf) * 100).toFixed(1)),
    voltageRating: `≥ ${Math.max(10, Math.ceil(vout * 1.6))} V`,
    packageRecommendation: 'Керамика MLCC X7R/X5R, типоразмер 1210 / 1206',
  };

  // 5. Input Capacitance (Cin)
  // RMS current: Irms = Iout * sqrt(D * (1 - D))
  const cinRmsA = ioutMax * Math.sqrt(dutyNom * (1 - dutyNom));
  const deltaVinRippleTarget = Math.max(0.1, vinMin * 0.02); // 2% input ripple
  const cinMinF = (ioutMax * dutyNom * (1 - dutyNom)) / (fsw * deltaVinRippleTarget);
  const cinMinUf = cinMinF * 1e6;

  // Derating factor for high Vin (ceramic MLCC derates up to 50% at 24V-48V)
  const cinTargetUf = cinMinUf / 0.5;
  const cinStandard = findCeilESeries(cinTargetUf, 'E24');
  let singleCinUf = 10;
  if (cinStandard.nominal > 40) singleCinUf = 22;
  const cinQty = Math.max(2, Math.ceil(cinStandard.nominal / singleCinUf));
  const totalCinUf = cinQty * singleCinUf;

  const cinComponent: StandardComponent = {
    theoretical: Number(cinMinUf.toFixed(1)),
    nominal: totalCinUf,
    unit: 'µF',
    formatted: `${cinQty} × ${singleCinUf} µF + 0.1 µF ВЧ`,
    series: 'E24',
    errorPercent: Number((((totalCinUf - cinMinUf) / cinMinUf) * 100).toFixed(1)),
    voltageRating: `≥ ${Math.ceil(vinMax * 1.35)} V (с запасом 35%)`,
    packageRecommendation: 'Керамика MLCC X7R 1210 (высокое рабочее напряжение)',
  };

  // 6. Feedback Divider (Rfb1, Rfb2)
  // Vref = 0.800V
  // Vout = Vref * (1 + Rfb_top / Rfb_bottom)
  const rfbBottomValK = 10.0; // 10.0 kΩ precision 1% (E96)
  const rfbTopCalcK = rfbBottomValK * (vout / SIC461_LIMITS.VREF - 1);
  const rfbTopStd = findNearestESeries(rfbTopCalcK, 'E96');

  const rfbBottomComp: StandardComponent = {
    theoretical: 10.0,
    nominal: 10.0,
    unit: 'kΩ',
    formatted: '10.0 kΩ',
    series: 'E96',
    errorPercent: 0,
    packageRecommendation: '0603 / 0805, 1%, 100ppm',
  };

  const rfbTopComp: StandardComponent = {
    theoretical: Number(rfbTopCalcK.toFixed(3)),
    nominal: rfbTopStd.nominal,
    unit: 'kΩ',
    formatted: `${rfbTopStd.nominal} kΩ`,
    series: 'E96',
    errorPercent: rfbTopStd.errorPercent,
    packageRecommendation: '0603 / 0805, 1%, 100ppm',
  };

  const voutActual =
    SIC461_LIMITS.VREF * (1 + rfbTopStd.nominal / rfbBottomComp.nominal);
  const voutErrorPercent = Number(
    (((voutActual - vout) / vout) * 100).toFixed(2)
  );

  // Optional feed-forward capacitor Cff across Rfb_top:
  // Cff = 1 / (2 * pi * fz * Rfb_top) with fz ~ 20kHz
  let cffPf: StandardComponent | undefined = undefined;
  if (rfbTopStd.nominal > 0) {
    const fz = 20000; // 20 kHz
    const cffCalcF = 1 / (2 * Math.PI * fz * (rfbTopStd.nominal * 1000));
    const cffCalcPf = cffCalcF * 1e12;
    const cffStd = findNearestESeries(cffCalcPf, 'E24');
    cffPf = {
      theoretical: Number(cffCalcPf.toFixed(1)),
      nominal: cffStd.nominal,
      unit: 'pF',
      formatted: `${cffStd.nominal} pF`,
      series: 'E24',
      errorPercent: cffStd.errorPercent,
      voltageRating: '≥ 25V',
      packageRecommendation: '0603 C0G / NP0 керамика',
    };
  }

  // 7. Soft-Start Capacitor (Css)
  // Iss = 5.0 µA
  // Css = (Iss * tss) / Vref = (5µA * tss_ms * 1e-3) / 0.8V
  const cssCalcF = (SIC461_LIMITS.ISS_UA * 1e-6 * (tssMs * 1e-3)) / SIC461_LIMITS.VREF;
  const cssCalcNf = cssCalcF * 1e9;
  const cssStd = findNearestESeries(cssCalcNf, 'E24');
  const actualTssMs =
    (cssStd.nominal * 1e-9 * SIC461_LIMITS.VREF) / (SIC461_LIMITS.ISS_UA * 1e-6) * 1000;

  const cssComponent: StandardComponent = {
    theoretical: Number(cssCalcNf.toFixed(2)),
    nominal: cssStd.nominal,
    unit: 'nF',
    formatted: `${cssStd.nominal} nF`,
    series: 'E24',
    errorPercent: cssStd.errorPercent,
    voltageRating: '≥ 16V',
    packageRecommendation: '0603 X7R керамика',
  };

  // 8. Current Limit (Rlim)
  // SiC461 cycle-by-cycle limit is configured through ILIM pin
  // Desired peak limit = max(iPeak * 1.25, 7.0)
  const ilimNominalA = Math.min(15.0, Math.max(6.0, Number((iPeak * 1.25).toFixed(1))));
  // Vishay empirical curve for Rlim on ILIM pin: Rlim ~ 5.6k to 47k
  const rlimCalcK = Number((4.2 * ilimNominalA - 5).toFixed(1));
  const rlimStd = findNearestESeries(Math.max(10, rlimCalcK), 'E96');
  const rlimComp: StandardComponent = {
    theoretical: rlimCalcK,
    nominal: rlimStd.nominal,
    unit: 'kΩ',
    formatted: `${rlimStd.nominal} kΩ`,
    series: 'E96',
    errorPercent: rlimStd.errorPercent,
    packageRecommendation: '0603 1%',
  };

  // 9. UVLO EN Divider (Ren1 top, Ren2 bottom)
  // Ven_rising = 1.20V
  const renBottomK = 10.0;
  const renTopCalcK = renBottomK * (vinStartUvlo / SIC461_LIMITS.VEN_RISING - 1);
  const renTopStd = findNearestESeries(renTopCalcK, 'E96');
  const actualVinStart = SIC461_LIMITS.VEN_RISING * (1 + renTopStd.nominal / renBottomK);
  const actualVinStop = SIC461_LIMITS.VEN_FALLING * (1 + renTopStd.nominal / renBottomK);

  const renTopComp: StandardComponent = {
    theoretical: Number(renTopCalcK.toFixed(2)),
    nominal: renTopStd.nominal,
    unit: 'kΩ',
    formatted: `${renTopStd.nominal} kΩ`,
    series: 'E96',
    errorPercent: renTopStd.errorPercent,
    voltageRating: `≥ ${Math.ceil(vinMax)} V`,
    packageRecommendation: '0805 / 0603 1%',
  };

  const renBottomComp: StandardComponent = {
    theoretical: 10.0,
    nominal: 10.0,
    unit: 'kΩ',
    formatted: '10.0 kΩ',
    series: 'E96',
    errorPercent: 0,
    packageRecommendation: '0603 1%',
  };

  // 10. Static Support Components for SiC461
  const cbootComp: StandardComponent = {
    theoretical: 100,
    nominal: 100,
    unit: 'nF',
    formatted: '100 nF (0.1 µF)',
    series: 'E12',
    errorPercent: 0,
    voltageRating: '≥ 25V',
    packageRecommendation: '0603 X7R керамика',
  };

  const rbootComp: StandardComponent = {
    theoretical: 3.3,
    nominal: 3.3,
    unit: 'Ω',
    formatted: '3.3 Ω',
    series: 'E24',
    errorPercent: 0,
    packageRecommendation: '0603 5% (демпфер звона узла SW)',
  };

  const cvddComp: StandardComponent = {
    theoretical: 4.7,
    nominal: 4.7,
    unit: 'µF',
    formatted: '4.7 µF',
    series: 'E12',
    errorPercent: 0,
    voltageRating: '≥ 10V',
    packageRecommendation: '0805 / 0603 X7R керамика',
  };

  const rpgoodComp: StandardComponent = {
    theoretical: 100,
    nominal: 100,
    unit: 'kΩ',
    formatted: '100 kΩ',
    series: 'E24',
    errorPercent: 0,
    packageRecommendation: '0603 5% подтяжка к VDD или 3.3V',
  };

  // 11. Efficiency and Loss Breakdown
  const rHighOhm = SIC461_LIMITS.RDS_ON_HIGH_MOHM * 1e-3;
  const rLowOhm = SIC461_LIMITS.RDS_ON_LOW_MOHM * 1e-3;
  const conductionLossW =
    Math.pow(iRms, 2) * (dutyNom * rHighOhm + (1 - dutyNom) * rLowOhm);
  const switchingLossW =
    0.5 * vinNom * ioutMax * (20e-9) * fsw; // Approx 20ns switching transition
  const inductorDcrOhm = 0.012; // 12 mOhm typical DCR
  const inductorDcrLossW = Math.pow(iRms, 2) * inductorDcrOhm;
  const quiescentLossW = 0.12;

  const totalLossW =
    conductionLossW + switchingLossW + inductorDcrLossW + quiescentLossW;
  const pOutW = vout * ioutMax;
  const estimatedEfficiency = Number(
    ((pOutW / (pOutW + totalLossW)) * 100).toFixed(1)
  );

  return {
    dutyNom: Number(dutyNom.toFixed(3)),
    dutyMin: Number(dutyMin.toFixed(3)),
    dutyMax: Number(dutyMax.toFixed(3)),
    tonNs: Number(tonNs.toFixed(1)),
    toffNs: Number(toffNs.toFixed(1)),
    tonMinWarning,
    toffMinWarning,
    deltaIL: Number(deltaILTarget.toFixed(2)),
    lCalcUh: Number(lCalcUh.toFixed(2)),
    lNominal: lComponent,
    actualDeltaIL: Number(actualDeltaIL.toFixed(2)),
    actualKind: Number(actualKind.toFixed(2)),
    iPeak: Number(iPeak.toFixed(2)),
    iValley: Number(iValley.toFixed(2)),
    iRms: Number(iRms.toFixed(2)),
    coutRippleMinUf: Number(coutRippleMinUf.toFixed(1)),
    coutTransientMinUf: Number(coutTransientMinUf.toFixed(1)),
    coutEffectiveMinUf: Number(coutEffectiveMinUf.toFixed(1)),
    coutRecommendedUf: coutComponent,
    coutQty,
    coutSingleUf: singleCoutUf,
    actualRippleMv: Number(actualRippleMv.toFixed(1)),
    cinRmsA: Number(cinRmsA.toFixed(2)),
    cinMinUf: Number(cinMinUf.toFixed(1)),
    cinRecommendedUf: cinComponent,
    cinQty,
    cinSingleUf: singleCinUf,
    vref: SIC461_LIMITS.VREF,
    rfbBottom: rfbBottomComp,
    rfbTop: rfbTopComp,
    voutActual: Number(voutActual.toFixed(3)),
    voutErrorPercent,
    cffPf,
    cssNf: cssComponent,
    actualTssMs: Number(actualTssMs.toFixed(2)),
    ilimNominalA,
    rlimKohm: rlimComp,
    renTopKohm: renTopComp,
    renBottomKohm: renBottomComp,
    actualVinStart: Number(actualVinStart.toFixed(2)),
    actualVinStop: Number(actualVinStop.toFixed(2)),
    cbootNf: cbootComp,
    rbootOhm: rbootComp,
    cvddUf: cvddComp,
    rpgoodKohm: rpgoodComp,
    estimatedEfficiency,
    estimatedPowerLossW: Number(totalLossW.toFixed(2)),
    conductionLossW: Number(conductionLossW.toFixed(2)),
    switchingLossW: Number(switchingLossW.toFixed(2)),
    inductorDcrLossW: Number(inductorDcrLossW.toFixed(2)),
    warnings,
  };
}

/**
 * Builds standard Bill of Materials (BOM) list for export and display
 */
export function generateBomList(
  inputs: CalculatorInputs,
  results: CalculatorResults
): BomItem[] {
  return [
    {
      id: 'U1',
      designator: 'U1',
      description: 'Синхронный понижающий регулятор 4.5V-60V, 10A, MLP55-27L',
      category: 'IC',
      nominalValue: 'SiC461ED-T1-GE3',
      calculatedValue: 'SiC461 (Vishay Siliconix)',
      tolerance: '±1% Vref',
      minRating: 'Vin = 60V, Iout = 10A',
      recommendedFootprint: 'PowerPAK MLP55-27L (5×5 мм)',
      notes: 'Синхронный регулятор со встроенными ключами MOSFET',
    },
    {
      id: 'L1',
      designator: 'L1',
      description: 'Силовой экранированный дроссель',
      category: 'Inductor',
      nominalValue: `${results.lNominal.nominal} µH`,
      calculatedValue: `${results.lCalcUh} µH`,
      tolerance: '±20%',
      minRating: results.lNominal.currentRating || `Isat ≥ ${(results.iPeak * 1.3).toFixed(1)}A`,
      recommendedFootprint: 'SMD Индуктор 10×10 или 12×12 мм',
      notes: `DCR < 15 мОм, Ipeak = ${results.iPeak}A, Irms = ${results.iRms}A`,
    },
    {
      id: 'CIN',
      designator: 'CIN1..CIN' + results.cinQty,
      description: 'Входные фильтрующие конденсаторы',
      category: 'Capacitor',
      nominalValue: `${results.cinQty} × ${results.cinSingleUf} µF`,
      calculatedValue: `${results.cinMinUf} µF мин.`,
      tolerance: '±10% (X7R)',
      minRating: results.cinRecommendedUf.voltageRating || `≥ ${Math.ceil(inputs.vinMax * 1.35)}V`,
      recommendedFootprint: 'SMD 1210 / 1206',
      notes: `Irms rating ≥ ${results.cinRmsA}A. Добавить параллельно 0.1 мкФ ВЧ керамику у вывода VIN`,
    },
    {
      id: 'COUT',
      designator: 'COUT1..COUT' + results.coutQty,
      description: 'Выходные сглаживающие конденсаторы',
      category: 'Capacitor',
      nominalValue: `${results.coutQty} × ${results.coutSingleUf} µF`,
      calculatedValue: `${results.coutEffectiveMinUf} µF мин.`,
      tolerance: '±10% (X7R)',
      minRating: results.coutRecommendedUf.voltageRating || `≥ ${Math.max(10, Math.ceil(inputs.vout * 1.6))}V`,
      recommendedFootprint: 'SMD 1210 / 1206',
      notes: `Пульсации на выходе ≈ ${results.actualRippleMv} мВ с учетом DC-bias`,
    },
    {
      id: 'RFB1',
      designator: 'RFB1 (Верхний)',
      description: 'Верхний резистор делителя обратной связи',
      category: 'Resistor',
      nominalValue: `${results.rfbTop.nominal} kΩ`,
      calculatedValue: `${results.rfbTop.theoretical} kΩ`,
      tolerance: '±1% (E96)',
      minRating: '1/10W, 50V',
      recommendedFootprint: 'SMD 0603',
      notes: `Фактическое Vout = ${results.voutActual} В (ошибка ${results.voutErrorPercent > 0 ? '+' : ''}${results.voutErrorPercent}%)`,
    },
    {
      id: 'RFB2',
      designator: 'RFB2 (Нижний)',
      description: 'Нижний резистор делителя обратной связи к AGND',
      category: 'Resistor',
      nominalValue: `${results.rfbBottom.nominal} kΩ`,
      calculatedValue: '10.0 kΩ',
      tolerance: '±1% (E96)',
      minRating: '1/10W, 50V',
      recommendedFootprint: 'SMD 0603',
      notes: 'Формирует ток делителя 80 мкА для помехоустойчивости FB',
    },
    ...(results.cffPf
      ? [
          {
            id: 'CFF',
            designator: 'CFF',
            description: 'Конденсатор опережения обратной связи (Feed-forward)',
            category: 'Capacitor' as const,
            nominalValue: `${results.cffPf.nominal} pF`,
            calculatedValue: `${results.cffPf.theoretical} pF`,
            tolerance: '±5% (C0G/NP0)',
            minRating: '≥ 25V',
            recommendedFootprint: 'SMD 0603',
            notes: 'Параллельно RFB1 для расширения полосы и запаса по фазе',
          },
        ]
      : []),
    {
      id: 'CSS',
      designator: 'CSS',
      description: 'Конденсатор времени мягкого старта (SS pin)',
      category: 'Capacitor',
      nominalValue: `${results.cssNf.nominal} nF`,
      calculatedValue: `${results.cssNf.theoretical} nF`,
      tolerance: '±10% (X7R)',
      minRating: '≥ 16V',
      recommendedFootprint: 'SMD 0603',
      notes: `Обеспечивает время нарастания Vout ≈ ${results.actualTssMs} мс`,
    },
    {
      id: 'RLIM',
      designator: 'RLIM',
      description: 'Резистор программирования пикового тока ограничения (ILIM pin)',
      category: 'Resistor',
      nominalValue: `${results.rlimKohm.nominal} kΩ`,
      calculatedValue: `${results.rlimKohm.theoretical} kΩ`,
      tolerance: '±1%',
      minRating: '1/10W',
      recommendedFootprint: 'SMD 0603',
      notes: `Устанавливает порог защиты по пиковому току ≈ ${results.ilimNominalA} А`,
    },
    {
      id: 'REN1',
      designator: 'REN1 (UVLO Top)',
      description: 'Верхний резистор делителя включения/UVLO от VIN к EN',
      category: 'Resistor',
      nominalValue: `${results.renTopKohm.nominal} kΩ`,
      calculatedValue: `${results.renTopKohm.theoretical} kΩ`,
      tolerance: '±1%',
      minRating: `≥ ${Math.ceil(inputs.vinMax)}V`,
      recommendedFootprint: 'SMD 0805 / 0603',
      notes: `Порог включения Vin_start = ${results.actualVinStart} В`,
    },
    {
      id: 'REN2',
      designator: 'REN2 (UVLO Bottom)',
      description: 'Нижний резистор делителя включения/UVLO от EN к AGND',
      category: 'Resistor',
      nominalValue: `${results.renBottomKohm.nominal} kΩ`,
      calculatedValue: '10.0 kΩ',
      tolerance: '±1%',
      minRating: '1/10W',
      recommendedFootprint: 'SMD 0603',
      notes: `Порог выключения Vin_stop = ${results.actualVinStop} В`,
    },
    {
      id: 'CBOOT',
      designator: 'CBOOT',
      description: 'Бутстрепный конденсатор накачки затвора верхнего MOSFET',
      category: 'Capacitor',
      nominalValue: '100 nF (0.1 µF)',
      calculatedValue: '100 nF',
      tolerance: '±10% (X7R)',
      minRating: '≥ 25V',
      recommendedFootprint: 'SMD 0603',
      notes: 'Включается между пинами BOOT и PHASE/SW',
    },
    {
      id: 'RBOOT',
      designator: 'RBOOT',
      description: 'Резистор демпфирования цепи бутстрепа (опционально)',
      category: 'Resistor',
      nominalValue: '3.3 Ω',
      calculatedValue: '2.2 - 4.7 Ω',
      tolerance: '±5%',
      minRating: '1/10W',
      recommendedFootprint: 'SMD 0603',
      notes: 'Последовательно с CBOOT для ограничения звона узла SW и EMI',
    },
    {
      id: 'CVDD',
      designator: 'CVDD',
      description: 'Блокировочный конденсатор внутреннего LDO 5V (VDD pin)',
      category: 'Capacitor',
      nominalValue: '4.7 µF',
      calculatedValue: '2.2 - 4.7 µF',
      tolerance: '±10% (X7R)',
      minRating: '≥ 10V',
      recommendedFootprint: 'SMD 0603 / 0805',
      notes: 'Монтировать максимально близко к выводу VDD и AGND',
    },
    {
      id: 'RPGOOD',
      designator: 'RPGOOD',
      description: 'Резистор подтяжки выхода Power Good (открытый сток)',
      category: 'Resistor',
      nominalValue: '100 kΩ',
      calculatedValue: '10 - 100 kΩ',
      tolerance: '±5%',
      minRating: '1/10W',
      recommendedFootprint: 'SMD 0603',
      notes: 'Подтяжка к VDD или внешнему логическому уровню 3.3V',
    },
  ];
}
