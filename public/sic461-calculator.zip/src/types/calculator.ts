export type VoutInputMode = 'voltage' | 'resistors';
export type SoftStartInputMode = 'time' | 'capacitor';
export type UvloInputMode = 'voltage' | 'resistors';

export interface CalculatorInputs {
  vinNom: number;       // Nominal input voltage (V)
  vinMin: number;       // Minimum input voltage (V)
  vinMax: number;       // Maximum input voltage (V)
  vout: number;         // Desired output voltage (V)
  ioutMax: number;      // Maximum continuous output current (A)
  fswKhz: number;       // Switching frequency (kHz)
  kind: number;         // Inductor ripple current ratio (typically 0.2 to 0.4, default 0.3)
  voutRippleMaxMv: number; // Maximum allowed output voltage ripple (mV)
  loadStepA: number;    // Transient load step for Cout design (A)
  voltageOvershootMv: number; // Max allowed overshoot/undershoot during load step (mV)
  tssMs: number;        // Soft-start time (ms)
  vinStartUvlo: number; // Custom UVLO rising threshold on VIN (V)
  vinStopUvlo?: number; // Custom UVLO falling threshold on VIN (V)

  // Mode flags defining how the parameter is specified (by value or by component nominals)
  voutInputMode: VoutInputMode;
  softStartInputMode: SoftStartInputMode;
  uvloInputMode: UvloInputMode;

  // Component values participating in the input definitions
  rfb1Kohm: number;     // Top feedback resistor (kΩ)
  rfb2Kohm: number;     // Bottom feedback resistor (kΩ)
  cssNf: number;        // Soft-start capacitor (nF)
  ren1Kohm: number;     // Top UVLO divider resistor (kΩ)
  ren2Kohm: number;     // Bottom UVLO divider resistor (kΩ)
}

export interface StandardComponent {
  theoretical: number;
  nominal: number;
  unit: string;
  formatted: string;
  series: 'E12' | 'E24' | 'E96';
  errorPercent: number;
  packageRecommendation?: string;
  voltageRating?: string;
  currentRating?: string;
}

export interface CalculatorResults {
  // Duty cycle
  dutyNom: number;
  dutyMin: number;
  dutyMax: number;
  
  // Timing
  tonNs: number;
  toffNs: number;
  tonMinWarning: boolean;
  toffMinWarning: boolean;

  // Inductor
  deltaIL: number;
  lCalcUh: number;
  lNominal: StandardComponent;
  actualDeltaIL: number;
  actualKind: number;
  iPeak: number;
  iValley: number;
  iRms: number;

  // Output Capacitor
  coutRippleMinUf: number;
  coutTransientMinUf: number;
  coutEffectiveMinUf: number;
  coutRecommendedUf: StandardComponent;
  coutQty: number;
  coutSingleUf: number;
  actualRippleMv: number;

  // Input Capacitor
  cinRmsA: number;
  cinMinUf: number;
  cinRecommendedUf: StandardComponent;
  cinQty: number;
  cinSingleUf: number;

  // Feedback Divider
  vref: number; // 0.8V
  rfbBottom: StandardComponent; // typically 10.0k
  rfbTop: StandardComponent;
  voutActual: number;
  voutErrorPercent: number;
  cffPf?: StandardComponent;

  // Soft-start
  cssNf: StandardComponent;
  actualTssMs: number;

  // Current limit
  ilimNominalA: number;
  rlimKohm: StandardComponent;

  // UVLO EN Divider
  renTopKohm: StandardComponent;
  renBottomKohm: StandardComponent;
  actualVinStart: number;
  actualVinStop: number;

  // Static support components
  cbootNf: StandardComponent;
  rbootOhm: StandardComponent;
  cvddUf: StandardComponent;
  rpgoodKohm: StandardComponent;

  // Efficiency & Power dissipation estimates
  estimatedEfficiency: number;
  estimatedPowerLossW: number;
  conductionLossW: number;
  switchingLossW: number;
  inductorDcrLossW: number;

  // Validation warnings
  warnings: string[];
}

export interface BomItem {
  id: string;
  designator: string;
  description: string;
  category: 'IC' | 'Inductor' | 'Capacitor' | 'Resistor';
  nominalValue: string;
  calculatedValue: string;
  tolerance: string;
  minRating: string;
  recommendedFootprint: string;
  notes: string;
}

export interface PresetProfile {
  id: string;
  name: string;
  description: string;
  inputs: CalculatorInputs;
}
